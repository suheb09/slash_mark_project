# Color-Detection-
color detection is an excellent data analytics project and an interactive application that will accurately identify the color in an image
